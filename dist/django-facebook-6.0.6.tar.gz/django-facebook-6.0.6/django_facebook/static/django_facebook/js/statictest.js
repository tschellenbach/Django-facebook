var errorDiv = document.getElementById('django_static_error');
errorDiv.style.display = 'none';
